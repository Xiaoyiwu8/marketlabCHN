import {loadNews} from '@/lib/news';
export async function GET(){return Response.json(await loadNews(),{headers:{'Cache-Control':'private, max-age=60'}})}
