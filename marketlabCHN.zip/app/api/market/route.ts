import { loadSeries } from '@/lib/provider';
export async function GET(req:Request){
 const p=new URL(req.url).searchParams,kind=p.get('kind')||'etf',code=(p.get('code')||'510300').toUpperCase();
 if(!['etf','nav','us'].includes(kind))return Response.json({error:'无效基金类型'},{status:400});
 try{return Response.json(await loadSeries(code,kind as 'etf'|'nav'|'us'),{headers:{'Cache-Control':'private, max-age=60'}})}catch(e){return Response.json({error:e instanceof Error?e.message:'行情加载失败',code,kind},{status:502})}
}
