import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'MarketLab 中国 · 基金研究台',description:'A股基金趋势、板块轮动、全球联动与条件式交易研究。'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="zh-CN"><body>{children}</body></html>}
