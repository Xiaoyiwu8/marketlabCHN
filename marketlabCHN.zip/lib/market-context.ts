import {analyze,mean} from './analysis.ts';
import {funds,type Series} from './funds.ts';
export const sectorProfiles:Record<string,{intro:string;watch:string;risk:string}>={
 红利:{intro:'以股息特征为核心的风格，不是单一行业；行业集中度随指数规则而变。',watch:'股息覆盖、盈利稳定性、利率与估值。',risk:'高股息可能来自股价下跌；分红并非承诺。'},
 半导体:{intro:'覆盖芯片设计、制造、封装测试及设备材料等产业链；具体权重以基金披露为准。',watch:'订单与库存周期、资本开支、国产替代与海外科技景气。',risk:'技术迭代、出口限制、估值波动及景气反转。'},
 医药:{intro:'涵盖药品、医疗器械和相关服务等方向；不同医药指数覆盖范围差异较大。',watch:'研发与商业化进度、医保政策、需求及利润兑现。',risk:'研发失败、政策变化与定价压力。'},
 消费:{intro:'围绕居民消费相关企业，不同消费指数的必选、可选消费比例不同。',watch:'居民收入与需求、渠道库存、品牌竞争力及利润率。',risk:'需求恢复不及预期、竞争加剧与估值回落。'},
 新能源:{intro:'本观察池用光伏ETF代表光伏产业链，不代表电池、风电等全部新能源方向。',watch:'供需与产能出清、产品价格、装机需求和贸易政策。',risk:'产能过剩、价格竞争、海外政策与技术替代。'},
 军工:{intro:'涉及航空航天、装备制造和相关材料电子等方向，具体业务以成份公司披露为准。',watch:'订单与交付、预算、收入确认及现金回款。',risk:'订单兑现不确定、交付周期与主题炒作波动。'},
 银行:{intro:'商业银行通过信贷、支付与其他金融服务经营，盈利受资产负债结构影响。',watch:'净息差、资产质量、信用需求与资本充足水平。',risk:'信用损失、息差压力及周期性风险。'},
 券商:{intro:'证券公司涉及经纪、投行、资管及投资交易等业务，通常对市场活跃度敏感。',watch:'交易量、融资活动、资本市场政策与业务盈利。',risk:'市场回落、自营波动、业务竞争与监管变化。'},
};
export function trendContext(s:Series|undefined,now=Date.now()){
 const a=analyze(s,now);if(!a||a.stale)return {a,valid:false,label:a?'数据过期':s?.error?'读取失败':'等待数据',short:'—',medium:'—',long:'—',ma120:null};
 const ma120=s!.bars.length>=120?mean(s!.bars.slice(-120).map(b=>b.close)):null;
 return {a,valid:true,label:a.bull?'上升':a.bear?'走弱':a.last.close<a.ma20?'回调':'震荡',short:a.last.close>a.ma20?'MA20上方':'MA20下方',medium:a.last.close>a.ma60?'MA60上方':'MA60下方',long:ma120==null?'样本不足':a.last.close>ma120?'MA120上方':'MA120下方',ma120};
}
export function marketBreadth(data:Record<string,Series>,now=Date.now()){
 const rows=funds.slice(0,4).map(f=>({...f,context:trendContext(data['etf:'+f.code],now)}));
 const valid=rows.filter(r=>r.context.valid),dates=new Set(valid.map(r=>r.context.a!.last.date));
 const aligned=valid.length===4&&dates.size===1;
 const bull=valid.filter(r=>r.context.a!.bull).length,bear=valid.filter(r=>r.context.a!.bear).length;
 return {rows,bull,bear,aligned,label:!aligned?'等待同日完整数据':bull>=3?'多数宽基上升':bear>=3?'多数宽基走弱':'大盘分化 / 震荡'};
}
