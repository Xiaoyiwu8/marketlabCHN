export type Bar={date:string;open:number;high:number;low:number;close:number;volume:number};
export type Fund={code:string;name:string;sector:string;market:'sh'|'sz';driver:string;us:string};
export const funds:Fund[]=[
{code:'510300',name:'沪深300ETF',sector:'宽基',market:'sh',driver:'盈利周期、国内信用与政策预期',us:'SPY'},
{code:'510500',name:'中证500ETF',sector:'宽基',market:'sh',driver:'中盘企业盈利与风险偏好',us:'SPY'},
{code:'159915',name:'创业板ETF',sector:'宽基',market:'sz',driver:'成长估值、利率与新能源产业链',us:'QQQ'},
{code:'588000',name:'科创50ETF',sector:'宽基',market:'sh',driver:'科技周期、国产替代与估值',us:'SOXX'},
{code:'510880',name:'红利ETF',sector:'红利',market:'sh',driver:'股息持续性、利率与国企盈利',us:'SPY'},
{code:'512480',name:'半导体ETF',sector:'半导体',market:'sh',driver:'芯片景气、资本开支与出口限制',us:'SOXX'},
{code:'512010',name:'医药ETF',sector:'医药',market:'sh',driver:'医保政策、创新药出海与研发兑现',us:'XLV'},
{code:'159928',name:'消费ETF',sector:'消费',market:'sz',driver:'收入预期、消费需求与企业利润',us:'XLP'},
{code:'515790',name:'光伏ETF',sector:'新能源',market:'sh',driver:'产能出清、组件价格与贸易政策',us:'ICLN'},
{code:'512660',name:'军工ETF',sector:'军工',market:'sh',driver:'订单兑现、预算与地缘事件',us:'ITA'},
{code:'512800',name:'银行ETF',sector:'银行',market:'sh',driver:'净息差、资产质量与信用需求',us:'XLF'},
{code:'512000',name:'券商ETF',sector:'券商',market:'sh',driver:'成交活跃度、资本市场政策与融资需求',us:'XLF'},
];
export type Series={code:string;name:string;kind:'etf'|'nav'|'us';bars:Bar[];source:string;adjustment:string;fetchedAt:string;quote?:{price:number;time:string};nav?:number;fundType?:string;error?:string};
export const ruleSources=[{title:'上交所：ETF T+1 / T+0',url:'https://www.sse.com.cn/assortment/fund/etf/question/c/c_20240118_5734755.shtml'},{title:'上交所交易规则（2026年修订）',url:'https://www.sse.com.cn/lawandrules/sselawsrules2025/stocks/exchange/c/c_20260424_10816482.shtml'},{title:'证监会：基金销售费用管理规定（2026年施行）',url:'https://www.csrc.gov.cn/csrc/c101954/c7606091/content.shtml'},{title:'天天基金：基金净值与档案',url:'https://fund.eastmoney.com/'}];
