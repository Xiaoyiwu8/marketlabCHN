import {analyze} from './analysis.ts';
import type {Series} from './funds.ts';
export function recommendation(series:Series|undefined,benchmark:Series|undefined,now=Date.now()){
 const a=analyze(series,now),m=analyze(benchmark,now);
 const result={action:'暂不建议操作',tone:'wait',trend:'等待数据',reason:'至少需要61个有效观测日。',entry:'等待完整数据后再评估买入。',exit:'不凭缺失数据决定卖出；已有风险计划仍需独立执行。',date:series?.bars.at(-1)?.date||'—',a};
 if(!a){if(series?.error)result.reason=series.error;return result}
 result.trend=a.bull?'上升趋势':a.bear?'中期走弱':a.last.close<a.ma20?'短期回调':'震荡整理';
 if(a.stale)return {...result,reason:'数据已过期，暂停买卖判断；请先更新数据。'};
 const type=series?.fundType||'';
 const equity=series?.kind==='etf'||(/股票|混合|指数/.test(type)&&!/债券|货币|QDII|商品|黄金/.test(type));
 if(!equity)return {...result,reason:`${type||'产品类别未确认'}：当前A股权益趋势规则不适用于此产品，不能仅凭净值均线建议买卖。`,entry:'债券需核对信用与久期；QDII需核对海外资产与汇率。',exit:'核对产品风险、持有期和费用后再决定赎回。'};
 const exit=series?.kind==='nav'?'按基金开放日提交赎回前，核对持有期费用与到账时间；不把研究指数当成交净值。':'按可卖份额分批减仓；T+1、跳空和涨跌停可能使成交偏离计划。';
 if(a.bear)return {...result,action:'建议卖出 / 减仓',tone:'sell',reason:'最新完整观测低于60日均线，中期趋势转弱；优先降低已有多头仓位。',entry:'空仓不买入，等待重回中期趋势。',exit};
 if(!m||m.stale)return {...result,reason:'基金数据有效，但沪深300大盘代理缺失或过期，暂停新增仓位建议。',exit:'已有持仓按原止损计划管理，不能把等待数据理解为必须持有。'};
 if(m.bear)return {...result,action:'建议观望 / 暂缓买入',reason:'沪深300代理低于60日均线，大盘风险过滤未通过。',entry:'先等待大盘修复，不因单只基金走强追买。',exit:'已有持仓尚未触发本规则卖出条件；继续检查60日均线及个人止损。'};
 const stretched=a.last.close/a.ma20-1>0.05;
 if(a.bull&&!stretched)return {...result,action:'建议分批买入',tone:'buy',reason:'收盘高于MA20、MA20高于MA60且较5个观测日前上升；大盘未跌破MA60，偏离MA20不超过5%。',entry:series?.kind==='nav'?'可考虑分批申购，先核实开放状态、份额费率与持有期限。':'可考虑分批建立仓位，先核实当前成交价、折溢价及流动性，避免满仓追入。',exit:'后续完整观测跌破MA60，或触及你事先设定的止损时，转为减仓评估。'};
 return {...result,action:stretched?'建议持有 / 不追高':'建议持有 / 等待确认',tone:'hold',reason:stretched?'趋势仍向上，但高于MA20超过5%，暂停追买。':'中期尚未跌破，但上升趋势条件不齐全，暂不新增仓位。',entry:stretched?'等待偏离收敛并保持上升趋势。':'等待价格、MA20和MA60恢复多头排列。',exit:'已有持仓继续观察；跌破MA60或个人止损则评估卖出。空仓保持观望。'};
}
