export const newsSources=[{id:'csrc',name:'证监会',url:'https://www.csrc.gov.cn/csrc/c100028/common_xq_list.shtml'},{id:'pbc',name:'中国人民银行',url:'https://www.pbc.gov.cn/goutongjiaoliu/113456/113469/index.html'}];
export type NewsItem={title:string;url:string;published:string;source:string;sectors:string[];category:string;watch:string};
export type NewsFeed={items:NewsItem[];fetchedAt:string;sources:{name:string;url:string;error?:string;count:number}[]};
const clean=(s:string)=>s.replace(/<[^>]*>/g,'').replace(/&(?:nbsp|amp|quot|lt|gt);/g,m=>({'&nbsp;':' ','&amp;':'&','&quot;':'"','&lt;':'<','&gt;':'>'}[m]||'')).trim();
export function classifyNews(title:string){
 const sectors:string[]=[];
 for(const [re,names] of [[/房地产|住房|房贷/,['地产','银行','建材']],[/降准|降息|利率|货币政策|信贷|再贷款|金融业/,['银行','宽基']],[/证券|资本市场|基金|上市|融资|分红|回购/,['券商','宽基']],[/芯片|半导体|集成电路/,['半导体']],[/医药|医保|创新药/,['医药']],[/消费|零售/,['消费']],[/光伏|新能源|储能/,['新能源']]] as [RegExp,string[]][]){if(re.test(title))sectors.push(...names)}
 const category=/征求意见/.test(title)?'征求意见 · 尚非最终规则':/办法|意见|规定|通知|降准|降息/.test(title)?'政策 / 规则':/数据|统计|资产|贷款|社融/.test(title)?'经济 / 金融数据':'监管动态';
 return {sectors:[...new Set(sectors)],category,watch:/征求意见/.test(title)?'关注最终条款、适用范围与正式生效时间。':/房地产|住房/.test(title)?'核实融资条件、适用企业和银行资产质量影响。':/降准|降息|利率|信贷|再贷款/.test(title)?'核实政策规模、期限及是否改变融资成本和信用供给。':'核实原文范围、执行时间及企业盈利影响；方向待验证。'};
}
function item(title:unknown,url:unknown,date:unknown,source:typeof newsSources[number],now:number):NewsItem|null{
 if(typeof title!=='string'||typeof url!=='string'||typeof date!=='string')return null;
 const published=date.trim(),stamp=Date.parse(published.replace(' ','T')+(published.length===10?'T00:00:00+08:00':'+08:00'));
 if(!Number.isFinite(stamp)||stamp>now||now-stamp>30*86400000)return null;
 const text=clean(title);if(!/政策|办法|意见|规定|通知|降准|降息|利率|信贷|再贷款|金融业|资本市场|上市公司|证券|基金|融资|分红|回购|房地产|芯片|半导体|医药|消费|新能源/.test(text))return null;
 let link:URL;try{link=new URL(url,source.url)}catch{return null}if(link.protocol!=='https:'||link.hostname!==new URL(source.url).hostname)return null;
 return {title:text.slice(0,220),url:link.href,published,source:source.name,...classifyNews(text)};
}
export function parseCsrc(data:unknown,now=Date.now()){
 const rows=(data as {data?:{results?:unknown[]}})?.data?.results;if(!Array.isArray(rows))throw Error('来源字段变化');
 return rows.map(r=>{const v=r as Record<string,unknown>;return item(v.title,v.url,v.publishedTimeStr,newsSources[0],now)}).filter((v):v is NewsItem=>!!v);
}
export function parsePbc(html:string,now=Date.now()){
 if(!html.includes('newslist_style'))throw Error('来源列表格式变化');
 const rows:NewsItem[]=[];for(const m of html.matchAll(/(<font\b[^>]*class="newslist_style"[\s\S]*?)<\/td>/g)){const a=m[1].match(/<a\b[^>]*href="([^"]+)"[^>]*\stitle="([^"]+)"[^>]*>/),date=m[1].match(/>(\d{4}-\d{2}-\d{2})<\/span>/);if(a&&date){const v=item(a[2],a[1],date[1],newsSources[1],now);if(v)rows.push(v)}}return rows;
}
let cached:{time:number;value:NewsFeed}|undefined;
export async function loadNews():Promise<NewsFeed>{
 if(cached&&Date.now()-cached.time<300000)return cached.value;
 const results=await Promise.all(newsSources.map(async s=>{try{const url=s.id==='csrc'?'https://www.csrc.gov.cn/searchList/a1a078ee0bc54721ab6b148884c784a8?_isAgg=true&_isJson=true&_pageSize=18&_template=index&_rangeTimeGte=&_channelName=&page=1':s.url;const r=await fetch(url,{signal:AbortSignal.timeout(12000)});if(!r.ok)throw Error('来源响应 '+r.status);const body=await r.text();if(body.length>3000000)throw Error('来源内容异常');const items=s.id==='csrc'?parseCsrc(JSON.parse(body)):parsePbc(body);return {items,status:{name:s.name,url:s.url,count:items.length}}}catch(e){return {items:[] as NewsItem[],status:{name:s.name,url:s.url,count:0,error:e instanceof Error?e.message:'读取失败'}}}}));
 const items=[...new Map(results.flatMap(r=>r.items).map(v=>[v.url,v])).values()].sort((a,b)=>b.published.localeCompare(a.published)).slice(0,16);
 const value={items,fetchedAt:new Date().toISOString(),sources:results.map(r=>r.status)};if(results.every(r=>!r.status.error))cached={time:Date.now(),value};return value;
}


