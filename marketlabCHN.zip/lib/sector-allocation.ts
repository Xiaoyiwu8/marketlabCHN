import {funds} from './funds.ts';
export type Allocation={code:string;name:string;date:string;industries:{name:string;weight:number}[];source:string;fetchedAt:string};
export function parseAllocation(raw:unknown,code:string,now=Date.now()):Allocation{
 const r=raw as {ErrCode?:number;Data?:{FundCode?:string;ShortName?:string;QuarterInfos?:{JZRQ?:string;HYPZInfo?:{BZDM?:string;HYMC?:string;ZJZBL?:string|number}[]}[]}};
 if(r.ErrCode!==0||r.Data?.FundCode!==code)throw Error('行业配置来源返回错误或基金代码不符');
 const quarters=(r.Data.QuarterInfos||[]).filter(q=>q.JZRQ&&/^\d{4}-\d{2}-\d{2}$/.test(q.JZRQ)&&Date.parse(q.JZRQ)<=now).sort((a,b)=>b.JZRQ!.localeCompare(a.JZRQ!));
 const q=quarters[0];if(!q?.HYPZInfo?.length)throw Error('尚无可用行业配置披露');
 const industries=q.HYPZInfo.map(x=>{if(x.BZDM!==code||typeof x.HYMC!=='string'||x.ZJZBL==null||x.ZJZBL==='')throw Error('行业配置字段不完整');const weight=Number(x.ZJZBL);if(!Number.isFinite(weight)||weight<0||weight>100)throw Error('行业占比无效');return {name:x.HYMC,weight}}).filter(x=>x.weight>0).sort((a,b)=>b.weight-a.weight);
 if(!industries.length)throw Error('本期未披露正值股票行业配置，可能为非股票或联接基金');
 if(industries.reduce((s,x)=>s+x.weight,0)>105)throw Error('行业占比合计异常');
 return {code,name:r.Data.ShortName||code,date:q.JZRQ!,industries,source:`https://fundf10.eastmoney.com/hytz_${code}.html`,fetchedAt:new Date(now).toISOString()};
}
export function themeLabels(code:string,name:string){const f=funds.find(f=>f.code===code);if(f)return {labels:[f.sector==='新能源'?'光伏 / 新能源':f.sector],basis:'观察池已核对分类'};
 const rules:[RegExp,string][]=[[/沪深300|中证500|中证1000|中证2000|上证50|科创50|创业板|中证A500/,'宽基'],[/红利|股息/,'红利'],[/半导体|芯片|集成电路/,'半导体'],[/医药|医疗|创新药|生物科技/,'医药医疗'],[/消费|食品|饮料|白酒/,'消费'],[/光伏/,'光伏'],[/新能源|电池|储能/,'新能源'],[/军工|国防/,'军工'],[/银行/,'银行'],[/证券公司|券商/,'券商'],[/人工智能|计算机|软件/,'科技 / AI'],[/黄金/,'黄金'],[/债券|纯债|短债|信用债/,'债券'],[/货币/,'货币']];
 const labels=rules.filter(([re])=>re.test(name)).map(([,label])=>label);return {labels:labels.length?labels:['综合配置 / 待确认'],basis:labels.length?'名称主题线索 · 待核实投资范围':'名称无明确主题，依据披露行业判断'};
}
