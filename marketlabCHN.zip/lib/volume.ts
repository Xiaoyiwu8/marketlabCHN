import {cleanBars} from './analysis.ts';
import type {Series} from './funds.ts';
export function volumeStats(series:Series|undefined,now=Date.now()){
 if(!series||series.error||series.kind==='nav')return null;
 const bars=cleanBars(series.bars),last=bars.at(-1);
 if(!last||now-Date.parse(last.date+'T00:00:00Z')>5*86400000||!Number.isFinite(last.volume)||last.volume<=0)return null;
 const previous=bars.at(-2)?.volume,base=bars.slice(-21,-1);
 const validBase=base.length===20&&base.every(b=>Number.isFinite(b.volume)&&b.volume>0);
 return {date:last.date,raw:last.volume,change:previous&&previous>0?(last.volume/previous-1)*100:null,ratio:validBase?last.volume/(base.reduce((n,b)=>n+b.volume,0)/20):null};
}
