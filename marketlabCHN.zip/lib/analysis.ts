import type { Bar,Series } from './funds.ts';
export const mean=(a:number[])=>a.length?a.reduce((s,v)=>s+v,0)/a.length:0;
export function cleanBars(input:Bar[]){
 const seen=new Set<string>();return [...input].sort((a,b)=>a.date.localeCompare(b.date)).filter(b=>{if(!/^\d{4}-\d{2}-\d{2}$/.test(b.date)||seen.has(b.date)||![b.open,b.close,b.high,b.low,b.volume].every(Number.isFinite)||Math.min(b.open,b.close,b.low)<=0||b.volume<0||b.high<Math.max(b.open,b.close,b.low)||b.low>Math.min(b.open,b.close))return false;seen.add(b.date);return true});
}
export function analyze(series:Series|undefined,now=Date.now()){
 if(!series||series.error||series.bars.length<61)return null;
 const b=series.bars,c=b.map(x=>x.close),last=b.at(-1)!,prev=b.at(-2)!,ma20=mean(c.slice(-20)),ma60=mean(c.slice(-60)),oldma20=mean(c.slice(-25,-5));
 const change=(n:number)=>(last.close/c[c.length-1-n]-1)*100;
 const vr=mean(b.slice(-21,-1).map(x=>x.volume));
 const atr=mean(b.slice(-14).map((x,i)=>Math.max(x.high-x.low,Math.abs(x.high-b[b.length-15+i].close),Math.abs(x.low-b[b.length-15+i].close))));
 const support=Math.min(...b.slice(-21,-1).map(x=>x.low)),resistance=Math.max(...b.slice(-21,-1).map(x=>x.high));
 let peak=c[0],dd=0;c.forEach(v=>{peak=Math.max(peak,v);dd=Math.min(dd,(v/peak-1)*100)});
 const dayEnd=Date.parse(last.date+'T23:59:59+08:00'),age=(now-dayEnd)/86400000,stale=age>4||age< -1;
 const bull=last.close>ma20&&ma20>ma60&&ma20>oldma20,bear=last.close<ma60;
 const status=stale?'数据过期':bear?'减仓观察':bull?'买入观察':'等待确认';
 return {last,prev,ma20,ma60,atr,support,resistance,dd,age,stale,bull,bear,status,day:(last.close/prev.close-1)*100,r5:change(5),r20:change(20),r60:change(60),volumeRatio:vr?last.volume/vr:null,stop:Math.max(support,last.close-2*atr)};
}
// Every China session pairs only with a strictly earlier US session. A same-date
// US close happens after China has closed and must never enter that day's signal.
export function linkage(cn:Bar[],us:Bar[],count=60){
 const pairs:{date:string;usDate:string;x:number;y:number}[]=[];
 for(let i=1;i<cn.length;i++){let j=us.length-1;while(j>0&&us[j].date>=cn[i].date)j--;if(j<1||us[j].date>=cn[i].date)continue;if((Date.parse(cn[i].date)-Date.parse(us[j].date))/86400000>4)continue;pairs.push({date:cn[i].date,usDate:us[j].date,x:us[j].close/us[j-1].close-1,y:cn[i].close/cn[i-1].close-1})}
 const p=pairs.slice(-count);if(p.length<30)return {n:p.length,r:null,pairs:p};const mx=mean(p.map(v=>v.x)),my=mean(p.map(v=>v.y));let xy=0,xx=0,yy=0;p.forEach(v=>{xy+=(v.x-mx)*(v.y-my);xx+=(v.x-mx)**2;yy+=(v.y-my)**2});return {n:p.length,r:xx&&yy?xy/Math.sqrt(xx*yy):null,pairs:p};
}
export function positionSize(capital:number,riskPct:number,entry:number,stop:number,capPct:number){
 if(![capital,riskPct,entry,stop,capPct].every(Number.isFinite)||capital<=0||riskPct<=0||riskPct>5||entry<=0||stop<=0||stop>=entry||capPct<=0||capPct>100)return null;
 const units=Math.floor(Math.min(capital*riskPct/100/(entry-stop),capital*capPct/100/entry)/100)*100;
 return {units,amount:units*entry,risk:units*(entry-stop)};
}
