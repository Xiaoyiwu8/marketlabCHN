import {cleanBars} from './analysis.ts';
import {funds,type Series} from './funds.ts';
export function parseEastmoney(raw:unknown,code:string,now=new Date()):Series{
 const r=raw as {rc?:number;data?:{code?:string;name?:string;klines?:string[]}};if(r.rc!==0||r.data?.code!==code||!Array.isArray(r.data.klines))throw Error('东方财富日线缺失或代码不符');
 const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(now),time=Number(new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Shanghai',hour:'2-digit',minute:'2-digit',hour12:false}).format(now).replace(':',''));
 const bars=cleanBars(r.data.klines.map(row=>{const x=row.split(',');return {date:x[0],open:Number(x[1]),close:Number(x[2]),high:Number(x[3]),low:Number(x[4]),volume:Number(x[5])}})).filter(b=>b.date<today||(b.date===today&&time>=1630)).slice(-300);
 if(bars.length<61)throw Error('东方财富完整日线不足61根');
 return {code,name:r.data.name||funds.find(f=>f.code===code)?.name||code,kind:'etf',bars,source:'东方财富公共历史行情 · 腾讯失败后的备用来源',adjustment:'来源前复权 fqt=1 · 无实时报价；成交量为来源原始口径',fetchedAt:now.toISOString()};
}
export async function eastmoneyMarket(code:string){const f=funds.find(f=>f.code===code);if(!f)throw Error('观察池外代码');const u=new URL('https://push2his.eastmoney.com/api/qt/stock/kline/get');u.search=new URLSearchParams({secid:`${f.market==='sh'?1:0}.${code}`,klt:'101',fqt:'1',lmt:'300',end:'20500101',fields1:'f1,f2,f3,f4,f5,f6',fields2:'f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61'}).toString();const r=await fetch(u,{signal:AbortSignal.timeout(10000),headers:{Referer:'https://quote.eastmoney.com/'}});if(!r.ok)throw Error(`东方财富响应 ${r.status}`);return parseEastmoney(await r.json(),code)}
