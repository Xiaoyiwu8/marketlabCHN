export const globalMarkets=[
 {code:'SPY',region:'美股 · 大盘',channel:'全球风险偏好、美元利率 → A股估值与外部融资环境',sectors:'宽基、金融、成长',source:'https://www.ssga.com/us/en/individual/etfs/spdr-sp-500-etf-trust-spy'},
 {code:'QQQ',region:'美股 · 科技',channel:'科技资本开支与盈利预期 → A股科技产业链',sectors:'半导体、计算机、消费电子',source:'https://www.invesco.com/qqq-etf/en/home.html'},
 {code:'VGK',region:'欧洲',channel:'欧洲需求、能源成本与欧元波动 → 中国出口企业订单和利润',sectors:'工业制造、汽车、光伏、消费',source:'https://advisors.vanguard.com/investments/products/vgk/vanguard-ftse-europe-etf'},
 {code:'EWJ',region:'亚洲 · 日本',channel:'日元与日本利率、设备和汽车周期 → 汇率竞争与制造供应链',sectors:'汽车、机械、半导体设备',source:'https://www.ishares.com/us/products/239665/ishares-msci-japan-etf'},
 {code:'EWY',region:'亚洲 · 韩国',channel:'存储芯片、电子出口与电池周期 → A股同产业链景气参照',sectors:'半导体、消费电子、电池',source:'https://www.ishares.com/us/products/239681/ishares-msci-south-korea-capped-etf'},
 {code:'EWH',region:'港股 · 香港市场样本',channel:'香港利率、地产与金融定价 → 区域风险偏好观察',sectors:'金融、地产、消费',source:'https://www.ishares.com/us/products/239657/ishares-msci-hong-kong-etf'},
 {code:'FXI',region:'港股 · 中国大型股',channel:'香港上市中国大型股定价 → A/H共同基本面与中国资产风险偏好',sectors:'金融、互联网、消费',source:'https://www.ishares.com/us/products/239536/ishares-china-large-cap-etf'},
];
