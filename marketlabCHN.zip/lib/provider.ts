import { cleanBars } from './analysis.ts';
import { funds,type Bar,type Series } from './funds.ts';
import { catalog } from './catalog.ts';
import {eastmoneyMarket} from './eastmoney-market.ts';
async function get(url:string){const tencent=url.startsWith('https://web.ifzq.gtimg.cn/');const urls=tencent?[url,url.replace('https://web.ifzq.gtimg.cn/','https://proxy.finance.qq.com/ifzqgtimg/')]:[url];let last='来源暂不可用';for(const u of urls){try{const r=await fetch(u,{signal:AbortSignal.timeout(10000),headers:{Referer:tencent?'https://gu.qq.com/':'https://fund.eastmoney.com/'}});if(!r.ok)throw Error(`来源响应 ${r.status}`);const t=await r.text();if(t.length>8_000_000)throw Error('来源数据过大');return t}catch(e){last=e instanceof Error?e.message:'来源失败'}}throw Error(last)}
export function extract(text:string,key:string){const m=text.match(new RegExp('var\\s+'+key+'\\s*=\\s*([\\s\\S]*?);'));if(!m)throw Error('来源字段缺失：'+key);return JSON.parse(m[1])}
function cnDate(d:Date){return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(d)}
export function parseNav(text:string,code:string):Series{
 if(extract(text,'ishb')===true)throw Error('货币基金采用万份收益等口径，不能使用净值趋势模型；请查看基金档案');
 if(extract(text,'fS_code')!==code)throw Error('返回基金代码不匹配');
 const raw=extract(text,'Data_netWorthTrend');if(!Array.isArray(raw)||raw.length<2)throw Error('没有可用净值历史');
 let level=100;const rows:Bar[]=[];let lastNav:number|undefined;
 for(const v of [...raw].sort((a,b)=>a.x-b.x)){if(!Number.isFinite(v.x)||!Number.isFinite(v.y)||v.y<=0||!Number.isFinite(v.equityReturn)||v.equityReturn<=-100)throw Error('净值或日增长率无效');level*=1+v.equityReturn/100;rows.push({date:cnDate(new Date(v.x)),open:level,high:level,low:level,close:level,volume:0});lastNav=v.y}
 const today=cnDate(new Date());const bars=cleanBars(rows).filter(b=>b.date<=today).slice(-300);
 return {code,name:extract(text,'fS_name'),kind:'nav',bars,nav:lastNav,source:'天天基金公开历史净值',adjustment:'按来源日增长率连乘的研究指数（非单位净值）；费用未扣除，非可成交价格',fetchedAt:new Date().toISOString()};
}
async function loadPrimary(code:string,kind:'etf'|'nav'|'us'):Promise<Series>{
 if(kind==='nav'){if(!/^\d{6}$/.test(code))throw Error('基金代码须为6位数字');const s=parseNav(await get(`https://fund.eastmoney.com/pingzhongdata/${code}.js`),code);try{s.fundType=(await catalog()).find(f=>f.code===code)?.type}catch{s.fundType='类别待核实'}return s}
 let id:string,endpoint:string;
 if(kind==='etf'){const f=funds.find(x=>x.code===code);if(!f)throw Error('该场内代码尚未纳入已核对观察池');id=f.market+code;endpoint='fqkline'}else{
 if(!['SPY','QQQ','SOXX','XLV','XLP','ICLN','ITA','XLF','VGK','EWJ','EWY','EWH','FXI'].includes(code))throw Error('不支持的美股代理');
 const d=JSON.parse(await get(`https://web.ifzq.gtimg.cn/appstock/app/usfqkline/get?param=us${code},day,,,2,qfq`));const ticker=d.data?.['us'+code]?.qt?.['us'+code]?.[2];if(typeof ticker!=='string'||!ticker.startsWith(code+'.'))throw Error('美股代码无法验证');id='us'+ticker;endpoint='usfqkline';}
 const json=JSON.parse(await get(`https://web.ifzq.gtimg.cn/appstock/app/${endpoint}/get?param=${id},day,,,300,qfq`));const d=json.data?.[id];if(!d)throw Error('未返回历史行情');const adjusted=Array.isArray(d.qfqday)&&d.qfqday.length;const raw=adjusted?d.qfqday:d.day;if(!Array.isArray(raw))throw Error('日线缺失');
 const now=new Date(),today=cnDate(now),hour=Number(new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Shanghai',hour:'2-digit',minute:'2-digit',hour12:false}).format(now).replace(':',''));
 const usToday=new Intl.DateTimeFormat('en-CA',{timeZone:'America/New_York',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
 const bars=cleanBars(raw.map((b:unknown[])=>({date:String(b[0]),open:Number(b[1]),close:Number(b[2]),high:Number(b[3]),low:Number(b[4]),volume:Number(b[5])}))).filter(b=>kind==='us'?b.date<usToday:b.date<today||(b.date===today&&hour>=1630));
 if(!bars.length)throw Error('没有完整交易日');const qt=d.qt?.[id];let quote:Series['quote'];if(kind==='etf'&&Number(qt?.[3])>0&&/^\d{14}$/.test(qt?.[30])){const t=qt[30];quote={price:Number(qt[3]),time:`${t.slice(0,4)}-${t.slice(4,6)}-${t.slice(6,8)}T${t.slice(8,10)}:${t.slice(10,12)}:${t.slice(12,14)}+08:00`}}
 return {code,name:qt?.[1]||funds.find(x=>x.code===code)?.name||code,kind,bars,quote,source:'腾讯公共延迟行情 · 无实时保证',adjustment:adjusted?'来源前复权 qfqday · 成交量为来源原始口径':'来源未复权 day · 分红可能影响趋势',fetchedAt:now.toISOString()};
}
const recent=new Map<string,{time:number;value:Series}>();
export async function loadSeries(code:string,kind:'etf'|'nav'|'us'):Promise<Series>{const key=kind+':'+code,hit=recent.get(key);if(hit&&Date.now()-hit.time<240000)return hit.value;let value:Series;try{value=await loadPrimary(code,kind)}catch(e){if(kind!=='etf')throw e;try{value=await eastmoneyMarket(code)}catch(f){throw Error(`腾讯与东方财富均未成功：${e instanceof Error?e.message:'腾讯失败'}；${f instanceof Error?f.message:'备用源失败'}。基金存在，请稍后重试。`)}}if(recent.size>=100)recent.delete(recent.keys().next().value!);recent.set(key,{time:Date.now(),value});return value}
