import {analyze} from './analysis.ts';
import {funds,type Series} from './funds.ts';
export function sectorRanking(data:Record<string,Series>,now=Date.now()){
 const market=analyze(data['etf:510300'],now),observations=funds.filter(f=>f.sector!=='宽基').map(f=>({...f,a:analyze(data['etf:'+f.code],now)}));
 const dates=observations.filter(f=>f.a&&!f.a.stale).map(f=>f.a!.last.date).sort();
 const date=market&&!market.stale?market.last.date:dates.at(-1);
 const rows=observations.filter(f=>f.a&&!f.a.stale&&f.a.last.date===date).sort((x,y)=>y.a!.r20-x.a!.r20).map((f,i)=>{const a=f.a!,relative=market&&!market.stale&&market.last.date===a.last.date?a.r20-market.r20:null,stretched=a.last.close/a.ma20-1>0.05;const strong=a.bull&&a.r20>0&&relative!==null&&relative>0;const buy=strong&&!stretched&&a.r5>0&&!!market&&!market.bear;return {...f,rank:i+1,relative,strong,buy,label:buy?'可分批布局':a.bear?'暂不推荐':stretched?'等回调，不追高':strong?'优先关注':'继续观察',reason:buy?'多头趋势、5日与20日上涨、跑赢大盘；大盘过滤通过且偏离MA20不超过5%。':a.bear?'低于60日均线，中期趋势尚未修复。':stretched?'高于20日均线超过5%，等待偏离收敛。':strong?(market?.bear?'板块相对强势，但大盘走弱，暂不新增仓位。':'板块趋势较强，等待短期动量确认。'):'尚未同时满足多头趋势、20日上涨与跑赢大盘。'}});
 return {date,rows,watch:rows.filter(f=>f.strong).slice(0,3),excluded:observations.filter(f=>!rows.some(r=>r.code===f.code)),marketBlocked:!market||market.stale||market.bear};
}
