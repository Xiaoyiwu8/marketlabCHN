import {analyze,cleanBars} from './analysis.ts';
import {funds,type Series} from './funds.ts';
import {recommendation} from './recommendation.ts';
import {volumeStats} from './volume.ts';
export function dailyPicks(input:Record<string,Series>,now=Date.now()){
 const data=Object.fromEntries(Object.entries(input).map(([k,s])=>[k,{...s,bars:cleanBars(s.bars)}]));
 const benchmark=data['etf:510300'],market=analyze(benchmark,now);
 const date=market?.last.date||null;
 const checked=funds.map(f=>{const s=data['etf:'+f.code],a=analyze(s,now),v=volumeStats(s,now),d= recommendation(s,benchmark,now);let reason='';
 if(!a||a.stale||a.last.date!==date)reason='数据缺失、过期或与大盘日期不一致';
 else if(d.tone!=='buy')reason=d.reason;
 else if(a.r5<=0||a.r20<=0)reason='5日或20日动量未转正';
 else if(f.code!=='510300'&&market&&a.r20<market.r20)reason='20日表现落后沪深300';
 else if(v?.ratio==null||v.ratio<0.8)reason='量能不足：最新量未达到前20日均量的0.8倍';
 return {...f,a,v,reason};});
 const candidates=checked.filter(f=>!f.reason).sort((x,y)=>y.a!.r5-x.a!.r5||y.a!.r20-x.a!.r20||x.code.localeCompare(y.code));
 const sectors=new Set<string>();const picks=candidates.filter(f=>{if(sectors.has(f.sector))return false;sectors.add(f.sector);return true}).slice(0,4);
 const validCount=checked.filter(f=>f.a&&!f.a.stale&&f.a.last.date===date).length;
 const blocked=!market||market.stale||market.bear;
 return {date,picks:blocked?[]:picks,validCount,total:funds.length,blocked,checked,reason:!market||market.stale?'大盘数据不足或过期，暂停新增仓位候选。':market.bear?'沪深300低于60日均线，大盘过滤未通过，今日不推荐新增仓位。':!picks.length?'当前没有同时满足趋势、动量和成交量条件的基金。':'按5日涨幅排序，20日涨幅作为同分排序；同一板块最多一只，宽基合计最多一只。'};
}
