import type {SearchFund} from './catalog.ts';
import type {Series} from './funds.ts';
export const peerGroups=[['沪深300','沪深300'],['中证500','中证500'],['创业板','创业板'],['科创50','科创50'],['红利','红利|股息'],['半导体','半导体|芯片|集成电路'],['医药医疗','医药|医疗|创新药|生物科技'],['消费','消费|白酒|食品|饮料'],['光伏','光伏'],['新能源','新能源|电池|储能'],['军工','军工|国防'],['银行','银行'],['券商','证券公司|券商'],['科技AI','人工智能|计算机|软件']] as const;
export function inferGroup(name:string){return peerGroups.find(([,pattern])=>new RegExp(pattern).test(name))?.[0]||''}
const family=(name:string)=>name.replace(/[A-Z](类|份额)?$/,'');
export function selectPeers(all:SearchFund[],current:SearchFund,group:string){const pattern=peerGroups.find(([g])=>g===group)?.[1];if(!pattern)throw Error('请选择支持的比较主题');const re=new RegExp(pattern),seen=new Set([family(current.name)]);return all.filter(f=>f.code!==current.code&&re.test(f.name)&&/股票|混合|指数/.test(f.type)&&!/债券|QDII|货币|增强/.test(f.name+f.type)).sort((a,b)=>a.code.localeCompare(b.code)).filter(f=>{const key=family(f.name);if(seen.has(key))return false;seen.add(key);return true}).slice(0,5)}
export function comparePeers(series:Series[],now=Date.now()){
 const valid=series.filter(s=>!s.error&&s.kind==='nav'&&s.bars.length>=61&&now-Date.parse(s.bars.at(-1)!.date+'T23:59:59+08:00')<4*86400000);
 if(valid.length<2)throw Error('至少需要两只基金的有效净值数据才能比较');
 const common=valid[0].bars.map(b=>b.date).filter(d=>valid.every(s=>s.bars.some(b=>b.date===d))).sort(),end=common.at(-1);
 if(!end||now-Date.parse(end+'T23:59:59+08:00')>4*86400000)throw Error('缺少近期共同净值日期');
 const start=(months:number)=>{const [y,m,d]=end.split('-').map(Number),base=new Date(Date.UTC(y,m-1-months,1)),lastDay=new Date(Date.UTC(base.getUTCFullYear(),base.getUTCMonth()+1,0)).getUTCDate();base.setUTCDate(Math.min(d,lastDay));const target=base.toISOString().slice(0,10),date=common.filter(d=>d<=target).at(-1);return date&&Date.parse(target)-Date.parse(date)<=7*86400000?date:null};
 const one=start(1),three=start(3);if(!one)throw Error('缺少近1月共同起点，暂不排名');
 const rows=valid.map(s=>{const value=(date:string)=>s.bars.find(b=>b.date===date)!.close;return {code:s.code,name:s.name,r1:(value(end)/value(one)-1)*100,r3:three?(value(end)/value(three)-1)*100:null}}).sort((a,b)=>b.r1-a.r1);
 return {end,start1:one,start3:three,rows,median:rows.length%2?rows[(rows.length-1)/2].r1:(rows[rows.length/2-1].r1+rows[rows.length/2].r1)/2};
}
