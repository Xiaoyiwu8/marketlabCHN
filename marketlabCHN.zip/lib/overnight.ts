import {cleanBars} from './analysis.ts';
import type {Series} from './funds.ts';
export function overnight(cn:Series|undefined,us:Series|undefined,now=Date.now()){
 if(!cn||cn.error||!us||us.error)return null;
 const c=cleanBars(cn.bars).at(-1),b=cleanBars(us.bars),last=b.at(-1);if(!c||!last||b.length<2)return null;
 const age=(now-Date.parse(last.date+'T21:00:00Z'))/86400000;
 if(age>4||age<0||last.date<c.date)return null;
 const i=b.findIndex(x=>x.date>=c.date);if(i<1)return null;
 const day=(last.close/b.at(-2)!.close-1)*100,change=(last.close/b[i-1].close-1)*100;
 return {day,change,usDate:last.date,cnDate:c.date,sessions:b.length-i,tone:change>=2?'positive':change<=-2?'negative':'neutral'};
}
