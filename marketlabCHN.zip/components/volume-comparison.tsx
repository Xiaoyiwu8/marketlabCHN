import {volumeStats} from '@/lib/volume';
import type {Series} from '@/lib/funds';
export function VolumeComparison({series}:{series:Series|undefined}){const v=volumeStats(series);return v?<><span>较前日 {v.change===null?'—':(v.change>0?'+':'')+v.change.toFixed(2)+'%'}</span><br/><b>20日均量 {v.ratio===null?'—':v.ratio.toFixed(2)+'倍'}</b></>:<span>量能数据不足</span>}
