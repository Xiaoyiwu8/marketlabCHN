'use client';
import {useEffect,useState} from 'react';
import {overnight} from '@/lib/overnight';
import {analyze} from '@/lib/analysis';
import {volumeStats} from '@/lib/volume';
import {funds,type Series} from '@/lib/funds';
const proxies=[
 {code:'SOXX',name:'半导体',cn:'512480'},
 {code:'QQQ',name:'纳指100 / 科技成长',cn:'159915'},
 {code:'XLV',name:'医疗保健',cn:'512010'},
 {code:'XLP',name:'必需消费',cn:'159928'},
 {code:'XLF',name:'金融',cn:'512800'},
 {code:'ITA',name:'航空航天与国防',cn:'512660'},
 {code:'ICLN',name:'全球清洁能源（美国上市）',cn:'515790'},
 {code:'SPY',name:'标普500 / 大盘',cn:'510300'},
];
const pct=(v:number)=>(v>0?'+':'')+v.toFixed(2)+'%';
function Volume({series}:{series:Series|undefined}){const v=volumeStats(series);return v?<><span>较前日 {v.change===null?'—':pct(v.change)}</span><br/><b>20日均量 {v.ratio===null?'—':v.ratio.toFixed(2)+'倍'}</b><small>最新量 {v.raw.toLocaleString('zh-CN',{maximumFractionDigits:2})}（来源原始单位）</small></>:<span>成交量缺失或过期</span>}
export function Overnight({cn,data:china}:{cn:Series|undefined;data:Record<string,Series>}){
 const [data,setData]=useState<Record<string,Series>>({}),[busy,setBusy]=useState(false),[retry,setRetry]=useState(0);
 useEffect(()=>{const ac=new AbortController();setBusy(true);void(async()=>{try{for(let i=0;i<proxies.length;i+=2){if(ac.signal.aborted)break;await Promise.all(proxies.slice(i,i+2).map(async f=>{try{const r=await fetch('/api/market?kind=us&code='+f.code,{signal:ac.signal}),s=await r.json() as Series;if(!r.ok||s.error)throw Error(s.error||'来源读取失败');if(!ac.signal.aborted)setData(d=>({...d,[f.code]:s}))}catch(e){if(!ac.signal.aborted)setData(d=>({...d,[f.code]:{code:f.code,name:f.name,kind:'us',bars:[],source:'',adjustment:'',fetchedAt:'',error:e instanceof Error?e.message:'读取失败'}}))}}))}}finally{if(!ac.signal.aborted)setBusy(false)}})();const timer=setInterval(()=>{if(!document.hidden)setRetry(x=>x+1)},300000);return()=>{ac.abort();clearInterval(timer)}},[retry]);
 const events=proxies.map(f=>({...f,s:overnight(cn,data[f.code])})).filter(f=>f.s&&f.s.tone!=='neutral');
 return <section className="card" aria-label="美股影响与板块量价比较"><div className="row"><div><span className="eyebrow">US MARKET → A SHARES · 重点外部因素</span><h2>美股影响观察 · 板块涨跌与成交量</h2></div><button className="secondary" disabled={busy} onClick={()=>setRetry(x=>x+1)}>{busy?'更新美股板块…':'更新美股影响'}</button></div>
 <div className="notice"><b>下一A股交易时段线索：</b>{events.length?events.map(f=><p key={f.code}>{f.name} {f.s!.tone==='positive'?'积极催化':'承压信号'}：A股最近完整日线 {f.s!.cnDate} 收盘后，海外累计 {pct(f.s!.change)}（截至美国交易日 {f.s!.usDate}，{f.s!.sessions}个交易日）。关注对应A股板块的开盘承接及量价配合。</p>):<p>{busy?'正在核实最新海外收盘…':'暂无达到±2%阈值且尚未被后续A股完整日线覆盖的海外事件；仍可查看下方单日表现。'}</p>}</div>
 <p>美股作为重点外部因素观察，国内政策、资金和估值也会影响A股。下表是相关方向的ETF代理比较，成分、权重与业务不同，不是两地同一板块指数；涨跌不保证同步。</p>
 <div className="peer-table"><table><thead><tr>{['美股方向 / 代理','美股单日涨跌','美股成交量变化','A股关联方向 / 代理','A股单日涨跌','A股成交量变化'].map(t=><th key={t}>{t}</th>)}</tr></thead><tbody>{proxies.map(f=>{const us=data[f.code],local=china['etf:'+f.cn],a=analyze(us),b=analyze(local),valid=a&&!a.stale,localValid=b&&!b.stale;return <tr key={f.code}><td><b>{f.name}</b><small>{f.code} · {a?.last.date||'—'} 美国交易日</small></td><td className={valid?(a.day>=0?'up':'down'):''}>{valid?pct(a.day):us?.error|| (busy?'读取中…':'数据不足或过期')}</td><td><Volume series={us}/></td><td>{funds.find(x=>x.code===f.cn)?.name}<small>{f.cn} · {b?.last.date||'—'} 中国交易日</small></td><td className={localValid?(b.day>=0?'up':'down'):''}>{localValid?pct(b.day):'数据不足或过期'}</td><td><Volume series={local}/></td></tr>})}</tbody></table></div>
 <p className="source">成交量比较使用各ETF自身同一来源：较前日变化 = 最新量/前日量−1；20日均量倍数 = 最新量/前20个完整交易日均量（不含最新日）。原始单位未统一，不跨市场比较绝对量；放量不等于资金净流入，缩量不必然看跌。场外基金没有可直接比较的场内成交量。</p>
 <p className="source">来源：腾讯公共完整日线；A股失败时备用东方财富，日期逐项显示。美国周五收盘在北京时间周六，两地同标签日期并非同时收盘。±2%仅为未经回测的事件阈值；未接A股盘中行情和权威交易日历，不能确认盘中是否已兑现。短期催化与下方MA20/60趋势分别展示，不自动触发买卖建议。</p>
 </section>
}
