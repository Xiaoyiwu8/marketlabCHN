'use client';
import {useEffect,useState} from 'react';
import {Combobox,ComboboxInput,ComboboxContent,ComboboxEmpty,ComboboxList,ComboboxItem} from '@/components/ui/combobox';
import type {SearchFund} from '@/lib/catalog';
export function FundSearch({onSelect}:{onSelect:(f:SearchFund)=>void}){
 const [query,setQuery]=useState(''),[items,setItems]=useState<SearchFund[]>([]),[status,setStatus]=useState('支持名称、代码或拼音首字母'),[selected,setSelected]=useState<SearchFund|null>(null);
 useEffect(()=>{const ac=new AbortController();if(!query.trim()){setItems([]);setStatus('支持名称、代码或拼音首字母');return}setItems([]);setStatus('正在搜索…');const timer=setTimeout(async()=>{try{const r=await fetch('/api/search?q='+encodeURIComponent(query.trim()),{signal:ac.signal});const d=await r.json() as {items:SearchFund[];error?:string};if(!r.ok)throw Error(d.error||'搜索失败');setItems(d.items);setStatus(d.items.length?'已找到候选基金，请从下拉列表选择' :'没有匹配结果，请换关键词或输入6位代码')}catch(e){if(!ac.signal.aborted)setStatus(e instanceof Error?e.message:'搜索暂不可用')}},300);return()=>{clearTimeout(timer);ac.abort()}},[query]);
 return <div className="global-search"><label htmlFor="fund-search">查询基金</label><Combobox items={items} filter={null} value={selected} inputValue={query} onInputValueChange={setQuery} itemToStringLabel={(f:SearchFund)=>f.name} isItemEqualToValue={(a:SearchFund,b:SearchFund)=>a.code===b.code} onValueChange={(f:SearchFund|null)=>{setSelected(f);if(f)onSelect(f)}}><ComboboxInput id="fund-search" placeholder="输入基金名称或代码，例如 沪深300 / 000001" showClear/><ComboboxContent><ComboboxEmpty>{status}</ComboboxEmpty><ComboboxList>{(f:SearchFund)=><ComboboxItem key={f.code} value={f}><div><b>{f.name}</b><small className="result-meta">{f.code} · {f.type}</small></div></ComboboxItem>}</ComboboxList></ComboboxContent></Combobox><small role="status">{status}</small></div>
}

