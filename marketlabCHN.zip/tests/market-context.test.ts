import {test} from 'node:test';
import assert from 'node:assert/strict';
import {marketBreadth,trendContext,sectorProfiles} from '../lib/market-context.ts';
import {funds,type Series} from '../lib/funds.ts';
const s:Series={code:'fixture',name:'fixture',kind:'etf',source:'test',adjustment:'test',fetchedAt:'',bars:Array.from({length:125},(_,i)=>{const c=100+i*.1;return {date:new Date(Date.UTC(2026,0,i+1)).toISOString().slice(0,10),open:c,high:c+1,low:c-1,close:c,volume:100}})};
const now=Date.parse(s.bars.at(-1)!.date+'T23:00:00Z');
test('aggregate requires four valid same-date histories',()=>{const data=Object.fromEntries(funds.slice(0,4).map(f=>['etf:'+f.code,s]));assert.equal(marketBreadth(data,now).label,'多数宽基上升');delete data['etf:510300'];assert.equal(marketBreadth(data,now).aligned,false);data['etf:510300']={...s,bars:s.bars.slice(0,-1)};assert.equal(marketBreadth(data,now).aligned,false)});
test('long trend requires 120 samples and stale data is marked invalid',()=>{assert.equal(trendContext(s,now).long,'MA120上方');assert.equal(trendContext({...s,bars:s.bars.slice(-90)},now).long,'样本不足');assert.equal(trendContext(s,now+86400000*10).valid,false)});
test('all sector proxies have introduction and risk coverage',()=>{for(const f of funds.filter(f=>f.sector!=='宽基'))assert.ok(sectorProfiles[f.sector]?.risk)});
