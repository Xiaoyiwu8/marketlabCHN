import test from 'node:test';
import assert from 'node:assert/strict';
import {volumeStats} from '../lib/volume.ts';
import type {Series} from '../lib/funds.ts';
const series:Series={code:'test',name:'test',kind:'etf',source:'',adjustment:'',fetchedAt:'',bars:Array.from({length:21},(_,i)=>({date:'2026-08-'+String(i+1).padStart(2,'0'),open:10,high:10,low:10,close:10,volume:i===20?200:100}))};
test('volume comparison excludes latest day from 20-day baseline',()=>{const v=volumeStats(series,Date.parse('2026-08-22'))!;assert.equal(v.change,100);assert.equal(v.ratio,2);assert.equal(volumeStats({...series,kind:'nav'},Date.parse('2026-08-22')),null);assert.equal(volumeStats(series,Date.parse('2026-09-06')),null)});
test('missing baseline volumes are not silently treated as zero activity',()=>{const bars=series.bars.map((b,i)=>i===5?{...b,volume:0}:b);assert.equal(volumeStats({...series,bars},Date.parse('2026-08-22'))!.ratio,null)});
