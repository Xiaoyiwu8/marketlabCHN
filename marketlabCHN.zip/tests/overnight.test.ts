import test from 'node:test';
import assert from 'node:assert/strict';
import {overnight} from '../lib/overnight.ts';
import type {Series} from '../lib/funds.ts';
const s=(dates:string[],values:number[]):Series=>({code:'test',name:'test',kind:'us',source:'',adjustment:'',fetchedAt:'',bars:dates.map((date,i)=>({date,close:values[i],open:values[i],high:values[i],low:values[i],volume:0}))});
test('Friday US catalyst remains visible before next A-share close without leaking into completed history',()=>{const cn=s(['2026-09-04'],[100]),us=s(['2026-09-03','2026-09-04'],[100,103.5]);const r=overnight(cn,us,Date.parse('2026-09-06'));assert.ok(r);assert.equal(r.tone,'positive');assert.equal(r.usDate,'2026-09-04');assert.equal(overnight(s(['2026-09-07'],[100]),us,Date.parse('2026-09-07T12:00Z')),null);assert.equal(overnight(cn,us,Date.parse('2026-09-12')),null)});
