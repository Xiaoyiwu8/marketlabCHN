import test from 'node:test';
import assert from 'node:assert/strict';
import {sectorRanking} from '../lib/sector-ranking.ts';
import type {Series} from '../lib/funds.ts';
const now=Date.parse('2026-09-06');
const series=(code:string,rate:number):Series=>({code,name:code,kind:'etf',source:'test',adjustment:'',fetchedAt:'',bars:Array.from({length:125},(_,i)=>{const close=100+i*rate;return {date:new Date(Date.UTC(2026,4,3+i)).toISOString().slice(0,10),close,open:close,high:close,low:close,volume:100}})});
test('sector ranking excludes different dates and separates market-blocked watch from buy',()=>{const data={'etf:510300':series('510300',-.05),'etf:512800':series('512800',.1),'etf:512000':series('512000',.2)};data['etf:512000'].bars.pop();const r=sectorRanking(data,now);assert.equal(r.rows.length,1);assert.equal(r.watch[0].sector,'银行');assert.equal(r.watch[0].buy,false);assert.equal(r.marketBlocked,true);assert.equal(r.excluded.some(f=>f.code==='512000'),true);});
